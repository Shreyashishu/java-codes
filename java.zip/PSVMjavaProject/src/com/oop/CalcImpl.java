package com.oop;

public class CalcImpl implements CalcInterface {

	@Override
	public double addition(double x, double y) {
		// TODO Auto-generated method stub
		return x+y;
	}

	@Override
	public double substraction(double x, double y) {
		// TODO Auto-generated method stub
		return x-y;
	}

	@Override
	public double multiply(double x, double y) {
		// TODO Auto-generated method stub
		return x*y;
	}

	@Override
	public double divide(double x, double y) {
		// TODO Auto-generated method stub
		return x/y;
	}

}
