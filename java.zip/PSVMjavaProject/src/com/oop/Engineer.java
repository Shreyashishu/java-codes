package com.oop;

public class Engineer extends Employee {
	
	private String englevel;
	
	public Engineer() {
		System.out.println("Engineer instance called");
	}

	public String getEnglevel() {
		return englevel;
	}

	public void setEnglevel(String englevel) {
		this.englevel = englevel;
	}

	@Override
	public String getVariablePay() {
		// TODO Auto-generated method stub
		return  "3% of base pay for all Engineers";
	}

	@Override
	public String toString() {
		return "Engineer [englevel=" + englevel + ", getEnglevel()=" + getEnglevel() + ", getVariablePay()="
				+ getVariablePay() + ", getEmpid()=" + getEmpid() + ", getEmpname()=" + getEmpname()
				+ ", getEmpaddress()=" + getEmpaddress() + "]";
	}
	

	
}
