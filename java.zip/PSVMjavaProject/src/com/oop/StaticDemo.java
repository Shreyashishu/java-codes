package com.oop;

public class StaticDemo {

	public void a() {
		System.out.println("a");
		//b();
	}
	
	public static void b() {
		System.out.println("b");
		//new StaticDemo().a();
	}
	
}
