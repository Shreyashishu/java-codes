package com.oop;

public interface CalcInterface {
	double addition(double x,double y);
	double substraction(double x,double y);
	double multiply(double x,double y);
	double divide(double x,double y);
	

}
