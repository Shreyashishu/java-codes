package com.oop;

public class Student {

	private int studentId;
	private String studentName;
	private double studentAvg;
	
	private static int counter;
	
	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public double getStudentAvg() {
		return studentAvg;
	}

	public void setStudentAvg(double studentAvg) {
		this.studentAvg = studentAvg;
	}
//
//	public static int getCounter() {
//		return counter;
//	}
//
//	public static void setCounter(int counter) {
//		Student.counter = counter;
//	}

//	public static String getSchoolAddress() {
//		return SCHOOL_ADDRESS;
//	}
//
	public static final String SCHOOL_ADDRESS = "St. Karens High School,Patna";
	
	public Student() {
		counter++;
		System.out.println("Instance Counter :" + counter);
	}
	
}
