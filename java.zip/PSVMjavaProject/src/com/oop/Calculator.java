package com.oop;

public class Calculator {

	public int addition(int x, int y) {
		return(x+y);
	}
	
	public double addition(double x, double y) {
		return(x+y);
	}
}
