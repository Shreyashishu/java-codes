package com.oop;

public class OOPRunner {
	
	public static void displayVP(Employee emp)
	
	{
		if(emp instanceof Manager) {
			System.out.println("I am a manager");
			System.out.println(emp.getVariablePay());
		}
		else if (emp instanceof Engineer) {
			System.out.println("I am a engineer");
			System.out.println(emp.getVariablePay());
		}
		
	}
	
	
   

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		
		StaticDemo.b();
		new StaticDemo().a();
		
//		System.out.println(Student.SCHOOL_ADDRESS);
//		
//		for(int i=0; i<10;i++) {
//			new Student();
//		}
////		
//		CalcInterface calc = new CalcImpl();
//		System.out.println(calc.addition(20, 30));
//		System.out.println(calc.multiply(10, 9));
//		System.out.println(calc.substraction(45, 9));
//		System.out.println(calc.divide(180, 90));
//		
		
		
		
		
//		Book book1 = new Book(101 , "java8" , 500.00);
//		Book book2 = new Book(102 , "Html 5" , 590.00);
//		Book book3 = new Book(103 , "C++" , 400.00);
//		
//		
//		System.out.println(book1.toString());
//		System.out.println(book2.toString());
//		System.out.println(book3.toString());
//		

	
		
		
		
		
//		Manager emp1 = new Manager();
//		System.out.println(emp1.getVariablePay());
//		
//		Engineer emp2 = new Engineer();
//		System.out.println(emp2.getVariablePay());
		
		
//		Book book1 = new Book();
//		Book book2 = new Book(101 , "java 21" , 500.00);
//		Book book3 = new Book(102, "Python");
//		Book book4 = new Book(103);
//		
//		
//		System.out.println(book2.getBookid() + "\t" + book2.getBookname() + "\t" + book2.getBookcost());
//		
		
		
//		Calculator calc =new Calculator();
//		System.out.println(calc.addition(5, 5));
//		System.out.println(calc.addition(5.0, 5.1));
//		System.out.println(calc.addition(4, 6.98760));
//		System.out.println(calc.addition(5, 9));
//		
//		
		

		Manager emp1 = new Manager();
		emp1.setEmpid(101);
		emp1.setEmpname("Kim");
		emp1.setEmpaddress("Banglore");
		emp1.setMngLevel("Senior Manager");
		
		Engineer emp2 = new Engineer();
		emp2.setEmpid(102);
		emp2.setEmpname("Lee");
		emp2.setEmpaddress("Mumbai");
		emp2.setEnglevel("System engineer");
		
		displayVP(emp1);
		displayVP(emp2);
		
//		System.out.println(emp1);
//		System.out.println(emp2);
//		
//		System.out.println(emp1.getMngLevel() + "\n" +emp2.getEnglevel() );
	}

}
