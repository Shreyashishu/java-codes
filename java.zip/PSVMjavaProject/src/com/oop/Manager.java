package com.oop;

public class Manager extends Employee {
	
	public Manager () {
		super();// Call to super class empty constructor - Implicit
		System.out.println("Manager instance created");
	}
	
	private String mngLevel;

	public String getMngLevel() {
		return mngLevel;
	}

	public void setMngLevel(String mngLevel) {
		this.mngLevel = mngLevel;
	}

	@Override
	public String getVariablePay() {
		// TODO Auto-generated method stub
		return "5% of the base pay to all the managers";
	}

	@Override
	public String toString() {
		return "Manager [mngLevel=" + mngLevel + ", getMngLevel()=" + getMngLevel() + ", getVariablePay()="
				+ getVariablePay() + ", getEmpid()=" + getEmpid() + ", getEmpname()=" + getEmpname()
				+ ", getEmpaddress()=" + getEmpaddress() + "]";
	}
	

}
