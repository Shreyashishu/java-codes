package com.oop;

import java.io.Serializable;

public class Book implements Serializable{
	
	private int bookid;
	private String bookname;
	private double bookcost;
	
	public Book() {
		System.out.println("Empty Constructor");
	}
	
	public Book(int bookid) {
		this.bookid = bookid;
	}
	
	public Book(int bookid , String bookname) {
		super();
		this.bookid = bookid;
		this.bookname = bookname;
		
	}
	
	public Book(int bookid , String bookname , double bookcost) {
		this.bookid = bookid;
		this.bookname = bookname;
		this.bookcost = bookcost;
		
	}

	public int getBookid() {
		return bookid;
	}

	public String getBookname() {
		return bookname;
	}

	public double getBookcost() {
		return bookcost;
	}

	@Override
	public String toString() {
		return super.toString()+":--Book [bookid=" + bookid + ", bookname=" + bookname + ", bookcost=" + bookcost + "]";
		
	}
	
	
	
	
	
	

}
