package com.qa;

public class Tester {

}
