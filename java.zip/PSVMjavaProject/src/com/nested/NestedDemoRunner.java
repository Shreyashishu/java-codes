package com.nested;

import com.oop.CalcImpl;
import com.oop.CalcInterface;

public class NestedDemoRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Outer.NonStaticInner inne = new Outer().new NonStaticInner();
		inne.innerclass_method();
		
		Outer.StaticInner.innerclass_method();

		CalcInterface calc = new CalcInterface() {
			
			@Override
			public double substraction(double x, double y) {
				// TODO Auto-generated method stub
				return x-y;
			}
			
			@Override
			public double multiply(double x, double y) {
				// TODO Auto-generated method stub
				return x*y;
			}
			
			@Override
			public double divide(double x, double y) {
				// TODO Auto-generated method stub
				return x/y;
			}
			
			@Override
			public double addition(double x, double y) {
				// TODO Auto-generated method stub
				return x+y;
			}
		};
		
		System.out.println(calc.addition(10 , 10));
		System.out.println(calc.multiply(30, 4));
	}

}
