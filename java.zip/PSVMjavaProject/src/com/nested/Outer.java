package com.nested;

public class Outer {

	//data
	//methods
	//constructor
	public class NonStaticInner{
		
		public void innerclass_method() {
			System.out.println("inner class method");
		}	}
	
	static public class StaticInner{
		
		public static void innerclass_method() {
			System.out.println("Static inner class method");
		}
		
     
		 
	}
	
}

