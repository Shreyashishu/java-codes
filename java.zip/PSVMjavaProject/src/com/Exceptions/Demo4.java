package com.Exceptions;

public class Demo4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int age = 5;
		try {
			
			if(age>20 && age<50)
			{
				System.out.println("User is having a Valid age");
			}
			else
			{
				throw new AgeExecution();
				
			}
			
		}
		catch(AgeExecution e ) {
			System.out.println(e.getexceptionmessage());
			e.printStackTrace();
		}
		
		System.out.println("Code Continue........");
	}

}
