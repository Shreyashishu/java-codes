package com.Exceptions;

public class Demo3 {

	public static void main(String[] args) throws AgeExecution {
		// TODO Auto-generated method stub
		
		int age=2;
		
		if(age>20 && age<50)
		{
			System.out.println("User is having valid age");
			
		}
		else {
			throw new AgeExecution();
			
			
		}
		
		System.out.println("Code Continue");
		
		

	}

}
