package com.Exceptions;

public class Demo2 {
	
	public static void main (String[] args) {
		
		try 
		{
			System.out.println("In try block");
			System.out.println(5/0);
			System.out.println("Try cont..");	
		}
//		catch(Exception e)
//		{
//			System.out.println("In catch block - generic catch");
//		}
		finally {
			System.out.println("In finally - always execute");
		}
		System.out.println("Code continue...");
		
		
		
	}
		
	

}
