package com.Exceptions;

public class AgeExecution extends Exception 
{
	
	public String getexceptionmessage() 
	{
		
		return "Invalid age";
		
	}
	
	
	

}
