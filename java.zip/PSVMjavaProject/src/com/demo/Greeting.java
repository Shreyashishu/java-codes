package com.demo;
public class Greeting {
	
	public void greet() {
		System.out.println("Welcome to the world of Java");
	}
}
