package com.run;

public class DataTypesDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		byte a = 10;
		short b=20;
		int c=30;
		long d=40;
		
		long e=c; //implicit conversion - conversion from lower to higher type - compiler
		int f=(int) e;  //explicit conversion - conversion from higher to lower type - programmer
		
		char g = 'a';
		float h = 10.00F;
		double i = 30.00;
		
		boolean j = false;
		System.out.println(j);

	}

}
