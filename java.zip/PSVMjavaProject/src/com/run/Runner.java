package com.run;


//import com.dev.DevLead;
//import com.dev.Developer;
//import com.qa.Tester;

public class Runner {

	public static void main(String[] args) {
		
		Employee emp1 = new Employee();
		emp1.setEmployeeId(101);
		emp1.setEmployeeName("Kim");
		emp1.setEmployeePhone(789012340);
		emp1.setEmployeeAddress("Banglore");
		
		
		Employee emp2 = new Employee();
		emp2.setEmployeeId(102);
		emp2.setEmployeeName("Lee");
		emp2.setEmployeePhone(987654567);
		emp2.setEmployeeAddress("Mumbai");
		
//		Employee emp3 = emp1;
		
		Employee emp3 = new Employee();
		emp3.setEmployeeId(101);
		emp3.setEmployeeName("Kim");
		emp3.setEmployeePhone(789012340);
		emp3.setEmployeeAddress("Banglore");
		
		
		System.out.println(emp1.getEmployeeId() + "\t" + emp1.getEmployeeName() + "\t" + emp1.getEmployeePhone() + "\t" + emp1.getEmployeeAddress());
		System.out.println(emp2.getEmployeeId() + "\t" + emp2.getEmployeeName() + "\t" + emp2.getEmployeePhone() + "\t" + emp2.getEmployeeAddress());
		System.out.println(emp3.getEmployeeId() + "\t" + emp3.getEmployeeName() + "\t" + emp3.getEmployeePhone() + "\t" + emp3.getEmployeeAddress());
		
//		emp1.displayEmployeeDetails();
//		emp2.displayEmployeeDetails();
//		emp3.displayEmployeeDetails();
//		
//		System.out.println(emp1==emp2);
//		System.out.println(emp2==emp3);
//		System.out.println(emp3==emp1);
//		System.out.println(emp1==emp4);
//		
		

		
		
//		new Greeting();
//		new Developer();
//		new Tester();
//		new DevLead();
		
	}

}
