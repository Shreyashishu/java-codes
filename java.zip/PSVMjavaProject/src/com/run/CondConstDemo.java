package com.run;

import java.util.Calendar;

public class CondConstDemo {

	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Calendar cal = Calendar.getInstance();
		int month=cal.get(cal.MONTH);
//		System.out.println(month);
		
		switch (month+1){
			case 6:
				System.out.println("this is june month");
			case 7:
				System.out.println("this is july month");
				break;
			case 8: 
				System.out.println("This is Ausgust");
				break;
			default:
				System.out.println("Invalid Month");
			
		}
		
				
		
//		int x=15;
//		boolean flag=true;
//		if(flag)
//		{
//			System.out.println("A positive integer");
//		}
//		else {
//			System.out.println("A negative integer");
//		}
		

	}

}
