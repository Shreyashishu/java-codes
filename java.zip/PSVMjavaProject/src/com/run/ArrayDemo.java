package com.run;

public class ArrayDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		
		
		
		String [][] userTable = new String[4][];
		userTable[0]=new String[2];
		userTable[1]=new String[2];
		userTable[2]=new String[2];
		userTable[3]=new String[] {"test@efg.com" , "34567"};
		
		userTable[0][0]="test@abc.com";
		userTable[0][1]="test6654";
		
		userTable[1][0]="test@xyz.com";
		userTable[1][1]="test1223";
		
		userTable[2][0]="test@pqr.com";
		userTable[2][1]="test8765";
		
		System.out.println("*****************Syntax1****************");
		for(String[] users:userTable){
			for(String user:users)
			{
				System.out.println(user + "\t\t");
			}
			System.out.println();
		}
		
		System.out.println("******************* Syntax2***********************");
		
		String[][] invalidusers = {{"wjnf@hgj.com" ,"54678"} , {"lkjhg@hjk.com" , "435678"} , {"jkhg@ghm.com" , "5467"}};
		
		for (String[] strings : invalidusers) {
			for (String string : strings) {
				System.out.println(string+"\t\t");
				
			}
			
			System.out.println();
		} 
		
		
		
		
//		int[] ids=new int[5];
//		ids[0]=100;
//		ids[1]=101;
//		ids[2]=102;
//		ids[3]=103;
//		ids[4]=104;
//		
//		System.out.println("********* For Loop **************");
//		for(int i=0;i<ids.length;i++)
//		{
//			System.out.println(ids[i]);
//		}
//		System.out.println("********** While Loop ******************");
//		int j=0;
//		while(j<ids.length)
//		{
//			System.out.println(ids[j]);
//			j++;
//			
//		}
//		System.out.println("************* For Each Loop ************");
//		for(int k:ids) {
//			System.out.println(k);
//			
//		}
//		
//		String[] cities = {"Banglore" , "Chennai" , "mumbai" , "Hyderabad"};
//		
//		for(String city : cities) {
//			System.out.println(city);
//			
//		}
		
//		Employee[] emps = new Employee[4];
//		emps[0]=new Employee();
//		emps[0].employeeId = 101;
//		emps[0].employeeName = "Lee";
//		emps[0].employeePhone = 986456789;
//		emps[0].employeeAddress = "Banglore";
//	
//		
//		
//		emps[1]=new Employee();
//		emps[1].employeeId = 102;
//		emps[1].employeeName = "Kim";
//		emps[1].employeePhone = 98756789;
//		emps[1].employeeAddress = "Hyderabad";
//	
//		
//		emps[3]=new Employee();
//		emps[3].employeeId = 103;
//		emps[3].employeeName = "Park";
//		emps[3].employeePhone = 87543456;
//		emps[3].employeeAddress = "Mumbai";
//		
//		
//		emps[2]=emps[0];
//		
//		for(Employee emp:emps) {
//			emp.displayEmployeeDetails();
//			System.out.println("*********************");
//		}
//	
	}

}
