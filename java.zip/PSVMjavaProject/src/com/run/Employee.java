package com.run;

public class Employee {
	
	//data
	private int employeeId;
	private String employeeName;
	private String employeeAddress;
	private long employeePhone;
	
	public void setEmployeeId(int employeeId)
	{
		if(employeeId>0 && employeeId<1000)
		{
			this.employeeId=employeeId;
			
		}
		else
		{
			this.employeeId = 0;
			System.out.println("Invalid id is set");
		}
		
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public void setEmployeeAddress(String employeeAddress) {
		this.employeeAddress = employeeAddress;
	}

	public void setEmployeePhone(long employeePhone) {
		this.employeePhone = employeePhone;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public String getEmployeeAddress() {
		return employeeAddress;
	}

	public long getEmployeePhone() {
		return employeePhone;
	}
	
	
	
	
	
	
			
//	//methods
//	public void displayEmployeeDetails() {
//		System.out.println(employeeId + "\n" + employeeName + "\n" + employeeAddress + "\n" + employeePhone);
//	}
//	//Constructor
//			public Employee() {
//				System.out.println("EIC");
//	
//	}

}
