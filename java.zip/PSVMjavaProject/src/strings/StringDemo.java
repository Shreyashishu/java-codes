package strings;

public class StringDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Synchronized - multi user environment
		StringBuffer sb1 = new StringBuffer("Welcome");
		sb1.append(" to the ");
		sb1.append("World");
		System.out.println(sb1);
		
		//Not Synchronized
		StringBuilder sb2 = new StringBuilder("Welcome");
		sb2.append(" to the ");
		sb2.append("World");
		System.out.println(sb2);
		
		
		
		
		
//		String text = "Welcome to World of Strings";
//		
//		System.out.println(text.length());
//		System.out.println(text.indexOf("W"));
//		System.out.println(text.indexOf("World"));
//		System.out.println(text.lastIndexOf("W"));
//		System.out.println(text.charAt(0));
//		System.out.println(text.substring(11));
//		System.out.println(text.substring(11, 16));
//		System.out.println(text.toLowerCase());
//		System.out.println(text.toUpperCase());
//		
//		String[] split = text.split(" ");
//		for(String s:split) {
//			System.out.println(s);
//		}
//		
//		System.out.println(text.contains("World"));
//		
//		char[] charArray = text.toCharArray();
//		for(char c:charArray) {
//			System.out.println(c);
//		}
//		int x = 567;
//		System.out.println(String.valueOf(x));
//		
		
		
		
		
		
		

//		String msg1 = "Hello";
//		String msg2 = new String("Welcome");
//		
//		System.out.println("String with Literals :->" + msg1);
//		System.out.println("String with new Keyword :->" + msg2);
//		
//		String s1 = "Kim";
//		String s2 = new String("Kim");
//		String s3 = new String(s1);
//		String s4 = "Kim";
//		String s5 = "kim";
//		
//		System.out.println("******************Reference match ******************");
//		
//		
//		System.out.println(s1 == s2);
//		System.out.println(s1 == s3);
//		System.out.println(s1 == s4);
//		System.out.println(s1 == s5);
//		
//		System.out.println("******************Content Match**********************");
//		
//		
//		System.out.println(s1.equals(s2));
//		System.out.println(s1.equals(s3));
//		System.out.println(s2.equals(s4));
//		System.out.println(s4.equals(s5));
//		System.out.println(s4.equalsIgnoreCase(s5));
//		System.out.println(s3.equals(s2));
//		System.out.println(s2.equals(s5));
//		
	}

}
