
public class ExcepHand {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int index=3;
		int[] ids= {10,20,30};
		try {
			System.out.println(ids[index]);
			System.out.println(5/index);
		}
		catch(ArithmeticException | ArrayIndexOutOfBoundsException | NullPointerException e) //Multi - Catch Block 
		
		{
			if (e instanceof ArithmeticException)
			{
				System.out.println("Division by zero is undefined");
				e.printStackTrace();
			}
			else if (e instanceof ArrayIndexOutOfBoundsException)
			{
				System.out.println("The index is out of Range");
				e.printStackTrace();
				
			}
			
		}
//		catch(ArrayIndexOutOfBoundsException e) {
//			System.out.println("The index is out of Range");
//			e.printStackTrace();
//			
//		}
		catch(Exception e) {
			System.out.println("Generic Exception - Handle any Exception");
		}
		System.out.println("Code Continuee.....");
		
	}

}
