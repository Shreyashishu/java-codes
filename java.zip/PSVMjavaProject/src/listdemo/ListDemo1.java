package listdemo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class ListDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		List<String> list = new ArrayList<String>();
//		
		LinkedList<String> list = new LinkedList<String>();
		
		System.out.println("the initial size : " + list.size());
		System.out.println("Elements in list : " +list);
		list.add("banglore");
		list.add("Chennai");
		list.add("Hyderabad");
		System.out.println("the initial size : " + list.size());
		System.out.println("Elements in list : " +list);
		list.add(1, "Mumbai"); //Second position in the collection
		System.out.println("the initial size : " + list.size());
		System.out.println("Elements in list : " +list);
//		list.add(10,"Pune");//will rise indexoutofBoundsException
		list.add("banglore");//duplicate values
		System.out.println("the initial size : " + list.size());
		System.out.println("Elements in list : " +list);
		
		list.remove(4);//remove the fifth element
		System.out.println("the initial size : " + list.size());
		System.out.println("Elements in list : " +list);
		
		String secondElement = list.get(1);//second element from collection is returned
		System.out.println("Second element in collection : " +secondElement);
		System.out.println("*****************For Loop***************");
		for(int i=0; i<list.size();i++) {
			System.out.println(list.get(i));
		}
		
		list.removeFirst();
		System.out.println("the initial size : " + list.size());
		System.out.println("Elements in list : " +list);
		
		list.removeLast();
		System.out.println("the initial size : " + list.size());
		System.out.println("Elements in list : " +list);
		
		
		
		System.out.println("***********************While loop*********************");
		int j=0;
		while(j<list.size())
		{
			System.out.println(list.get(j));
			j++;
		}
		System.out.println("************************For Each Loop*******************");
		for(String city:list)
		{
			System.out.println(city);
		}
		System.out.println("***********************Iterator*****************");
		Iterator<String> it = list.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		System.out.println("************************Lambdas***********************");
		list.forEach((city) -> System.out.println(city));
		
		
		

	}

}
