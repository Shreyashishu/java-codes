package listdemo;

import java.util.Vector;

public class VectorDemo2 {
	public static void main(String[] args) {
		Vector<String> vect = new Vector<String>();
		System.out.println("Size of vector :" +vect.size());
		System.out.println("Capacity of vector :" +vect.capacity());
		System.out.println(vect);
		vect.add("banglore");
		vect.add("chennai");
		System.out.println("Size of vector :" +vect.size());
		System.out.println("Capacity of vector :" +vect.capacity());
		System.out.println(vect);
		
		for(String s:vect) {
			System.out.println(s);
			
		}
		
		
	}

}
