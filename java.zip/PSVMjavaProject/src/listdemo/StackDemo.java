package listdemo;

import java.util.Stack;

public class StackDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Stack<String> st = new Stack<String>();
		st.add("banglore");
		st.add("chennai");
		System.out.println(st.add("mumbai"));
		
		System.out.println(st.size());
		System.out.println(st);
		
		st.push("pune");
		System.out.println(st.size());
		System.out.println(st);
		
		System.out.println(st.pop());//pop the last element - LIFO manner
		System.out.println(st.size());
		System.out.println(st);
		st.push("Bihar");
		System.out.println(st.pop());//pop the last element - LIFO manner
		System.out.println(st.size());
		System.out.println(st);
		System.out.println(st.contains("banglore"));
		

	}

}
