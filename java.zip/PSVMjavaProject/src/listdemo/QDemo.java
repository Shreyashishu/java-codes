package listdemo;

import java.util.LinkedList;
import java.util.Queue;

public class QDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Queue<String> qu = new LinkedList<String>();
		
		qu.add("banglore");
		qu.add("chennai");
		qu.add("hyderabad");
		
		qu.offer("pune");//similar to add method
		
//		System.out.println(qu.poll());//get the head & remove
		System.out.println(qu.peek());//get the head
		System.out.println(qu);
		
		
		

	}

}
