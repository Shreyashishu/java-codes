package java8;
@FunctionalInterface
public interface DemoInterface {
	void greet();

}
