package java8;

@FunctionalInterface
public interface FunInterface {


	//SAM - Single Abstract Method
	String greet();
	
	//Multiple Static Method
	public static void sayHello()
	{
		System.out.println("Say Hello - Static");
	}
	
	public static void sayHi()
	{
		System.out.println("Say Hi - Static");
	}
	
	//Multiple Default Method
	public default void welcome()
	{
		System.out.println("Welcome Default");
	}

}
