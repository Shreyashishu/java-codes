package java8;

public class Product {
	
	private int productid;
	private String productname;
	private double productprice;
	
	public Product(int productid, String productname, double productprice) {
		super();
		this.productid = productid;
		this.productname = productname;
		this.productprice = productprice;
	}

	@Override
	public String toString() {
		return "Product [productid=" + productid + ", productname=" + productname + ", productprice=" + productprice
				+ "]";
	}

	public int getProductid() {
		return productid;
	}

	public String getProductname() {
		return productname;
	}

	public double getProductprice() {
		return productprice;
	}
	

}
