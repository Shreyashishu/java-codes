package java8;

@FunctionalInterface
public interface MathInterface {

	//SAM
		double compute(double x, double y);
}
