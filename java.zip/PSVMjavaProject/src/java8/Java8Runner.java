package java8;

public class Java8Runner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		MathInterface mathAdd = (x,y) -> x+y;
		System.out.println(mathAdd.compute(20, 20));
		
		MathInterface mathSub = (x,y) -> x-y;
		System.out.println(mathSub.compute(20, 20));
		
		MathInterface mathDiv = (x,y) -> x/y;
		System.out.println(mathDiv.compute(10, 5));
		
		MathInterface mathMul = (x,y) -> x*y;
		System.out.println(mathMul.compute(10, 9));
		
		GreetInterface greet = () -> {return "Welcome to Lambdas";};
		System.out.println(greet.greet());
		
		
		/*
		//static methods
		FunInterface.sayHello();
		FunInterface.sayHi();
		
		FunInterface fi = new FunInterface() {
			
			@Override
			public String greet() {
				// TODO Auto-generated method stub
				return "Greet - SAM";
			}
			
			@Override
			public void welcome()
			{
				FunInterface.super.welcome();
				System.out.println("Welcome Override");
			}
		};
		
		fi.greet();
		fi.welcome();
		*/
		

//	}
	}

}
