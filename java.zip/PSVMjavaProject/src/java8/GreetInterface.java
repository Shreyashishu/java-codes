package java8;
@FunctionalInterface
public interface GreetInterface {
	
	//SAM
		String greet();

}
