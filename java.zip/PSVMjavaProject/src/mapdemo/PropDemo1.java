package mapdemo;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

public class PropDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			FileReader fr = new FileReader("src/props/testev.properties");
			Properties properties = new Properties();
			properties.load(fr);
			
			System.out.println(properties.get("url"));
			System.out.println(properties.get("username"));
			System.out.println(properties.get("password"));
			System.out.println(properties.get("environment"));
			
			System.out.println("***************** Properties file - Entry");
			Set<Entry<Object, Object>> entryset = properties.entrySet();
			for(Entry<Object, Object> entry:entryset) {
				System.out.println(entry.getKey()+"-->" + entry.getValue());
				
			}
			
			
		
		}
		catch(FileNotFoundException e){
			e.printStackTrace();
			
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("Code Cont....");

	}

}
