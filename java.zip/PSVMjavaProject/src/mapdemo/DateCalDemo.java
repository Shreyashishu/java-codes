package mapdemo;

import java.text.SimpleDateFormat;
import java.util.Calendar;
//import java.util.Date;
import java.util.Date;

public class DateCalDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Date date = new Date();
		System.out.println(date);
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy:mm:ss:ms");
		System.out.println(sdf.format(date));
		
		Calendar cal = Calendar.getInstance();
		System.out.println(cal.get(Calendar.WEEK_OF_YEAR));
		cal.add(Calendar.YEAR, 5);//add 5 years to the current year
		System.out.println(cal.get(Calendar.YEAR));
		
	}

}
