package mapdemo;

import java.util.StringTokenizer;

public class StDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String text="Constructs a string tokenizer for the specified string. The tokenizer uses the default delimiter set, which is the space character, the tab character, the newline character, the carriage-returr character, and the form-feed character. Delimiter characters themselves will not be treated as tokens.";
		
		StringTokenizer st = new StringTokenizer(text ,",.",true);
		System.out.println("No. of Tokens :" +st.countTokens());
		while(st.hasMoreTokens()) {
			System.out.println(st.nextToken());
		}
		

	}

}
