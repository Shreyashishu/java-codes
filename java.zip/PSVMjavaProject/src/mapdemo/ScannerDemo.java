package mapdemo;

import java.util.Scanner;

public class ScannerDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try (Scanner scan = new Scanner(System.in)){
		
		System.out.println("Enter Employee Id");
		int id = scan.nextInt();
		System.out.println("Enter Employee Name");
		String name = scan.next();
		System.out.println("Enter Employee Phone");
		long phone = scan.nextLong();
		
		System.out.println(id+"\t" + name +"\t" + phone );
		}
		
		

	}

}
