package mapdemo;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import com.oop.Book;

public class HashDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		Map<String,Book> map = new HashMap<String,Book>();
//		Map<String,Book> map = new LinkedHashMap<String,Book>();
		Map<String,Book> map = new TreeMap<String,Book>();
		
		map.put("ISBNBK911", new Book(911 , "java8" , 5000.00));
		map.put("ISBNBK343", new Book(343 , "PLSql" , 500.00));
		map.put("ISBNBK341", new Book(341 , "html5" , 3424.00));
		map.put("ISBNBK467", new Book(467 , "css3" , 5065.00));
		map.put("ISBNBK234", new Book(234 , "SQL" , 500.00));
		
		System.out.println(map.size());//retrieve the size of map
		System.out.println(map);//display map
		
		Set<String> keyset = map.keySet();	//retrieve the key from map as a set Collection
		System.out.println(keyset);
		
		Collection<Book> values = map.values(); //retrieve the values from map as collection
		System.out.println(values);
		
		map.put("ISBNBK234", new Book(555 , "SQL New" , 555.00));//duplicate key - will update with latest values
		
		values = map.values();
		System.out.println(values);
		
		map.remove("ISBNBK341");//remove the key from map
		System.out.println(map.size());//retrieve the size of map
		keyset = map.keySet();
		System.out.println(keyset);
		
		for(String key:keyset) {
			System.out.println(key+"-->"+map.get(key));
		}
	}

}
