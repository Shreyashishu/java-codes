package io;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.List;

import com.oop.Book;

public class ReadObjects {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try(ObjectInputStream objectInputStream=new ObjectInputStream(new FileInputStream("src\\io\\book.dat")))
		{
			List<Book> list = (List<Book>) objectInputStream.readObject();
			for(Book book:list) {
				System.out.println(book);
			}
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
	}

}
