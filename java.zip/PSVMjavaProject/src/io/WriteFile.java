package io;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class WriteFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		File file = new File("src\\io\\Greeting.txt");
		String message = "Welcome to DTA Launchpad";
		
		
		try(FileOutputStream fileOutputStream = new FileOutputStream(file , true )) {
			
			fileOutputStream.write(message.getBytes());
			System.out.println("Data to file is written");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}

}
