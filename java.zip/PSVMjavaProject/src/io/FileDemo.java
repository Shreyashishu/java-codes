package io;

import java.io.File;
import java.io.IOException;
import java.util.Date;

public class FileDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		File file = new File("C:\\Users\\10shr\\eclipse-workspace\\PSVMjavaProject");

		String[] list = file.list();
		for(String s:list) {
			System.out.println(s);
		}
		
		file = new File("src\\io\\welcome.txt");
		boolean newFile = file.createNewFile();
		if(newFile)
		{
			System.out.println("file created :-->" + file.getAbsolutePath());
			
		}
		else {
			System.out.println("file already exists :-->" + file.getAbsolutePath());
			
		}
		System.out.println(file.canRead());
		System.out.println(file.canWrite());
		System.out.println(new Date(file.lastModified()));
		System.out.println(file.isHidden());
		System.out.println(file.length());
	}

}
