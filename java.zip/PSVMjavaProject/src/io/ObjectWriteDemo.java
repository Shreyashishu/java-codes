package io;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import com.oop.Book;

public class ObjectWriteDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Book> list=new ArrayList<Book>();
		
		list.add(new Book(101,"java8",500.00));
		list.add(new Book(102,"html5",500.00));
		list.add(new Book(103,"css3",500.00));
		
		try (ObjectOutputStream oos = new ObjectOutputStream
				(new FileOutputStream("src\\io\\book.dat")))
		{
			oos.writeObject(list);
			System.out.println("Book list is written to file");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
