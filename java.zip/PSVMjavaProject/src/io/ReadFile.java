package io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class ReadFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		File file = new File("src\\io\\welcome.txt");
		
		//file stream : create a connection between the file & program

		try(FileInputStream fileInputStream = new FileInputStream(file)){
			
			byte[] allBytes = fileInputStream.readAllBytes();
			for(byte b:allBytes) {
				System.out.println((char)b);
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
