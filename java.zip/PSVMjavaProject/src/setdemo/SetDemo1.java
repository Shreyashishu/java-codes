package setdemo;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		Set<String> set = new HashSet<String>();
//		Set<String> set = new LinkedHashSet<String>();
		Set<String> set = new TreeSet<String>();
		
		set.add("pune");
		set.add("mumbai");
		set.add("banglore");
		set.add("chennai");
		set.add("hyderabad");
		
		
		System.out.println(set.size());
		System.out.println(set);
		
		set.add("pune");//duplicate values won't get add
		System.out.println(set.size());
		System.out.println(set);
		
		System.out.println(set.add("hyderabad"));
		System.out.println(set.add("bihar"));
		System.out.println(set.size());
		System.out.println(set);
		
		
		for(String s:set) {
			System.out.println(s);
		}
			
		
	}

}
