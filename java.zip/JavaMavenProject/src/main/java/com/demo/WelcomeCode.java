package com.demo;

public class WelcomeCode {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Welcome Code");
		
	}

}
